import React from 'react';
import Contacts from "./components/contacts/index.js";
import AddContact from "./components/addContact/index.js";
import Profile from "./components/profile/index.js";

class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      contacts: [],
      profile: [],
      removed: []
    }
  }
  componentDidMount() {
    this.displayProfile();
    this.refreshContacts();
  }

  refreshContacts = () => {
    const currentTimeMilliseconds = new Date().getTime();
    fetch(`http://plato.mrl.ai:8080/contacts?cachebuster=${currentTimeMilliseconds}`, {
      "method": "GET",
      "headers": {
        "api": "sommer"
      }
    })
      .then(res => res.json())
      .then((data) => {
        this.setState({ contacts: data.contacts })
      })
      .catch(console.log)
  }

  displayProfile = () => {
    const currentTimeMilliseconds = new Date().getTime();
    fetch(`http://plato.mrl.ai:8080/profile?cachebuster=${currentTimeMilliseconds}`, {
      "method": "GET",
      "headers": {
        "api": "sommer"
      }
    })
      .then(res => res.json())
      .then((data) => {
        this.setState({ profile: data })
      })
      .catch(console.log)
  }


  personAdd = (event) => {
    event.preventDefault();

    const name = document.getElementById("addName").value;
    const number = document.getElementById("addNumber").value;
    const currentTimeMilliseconds = new Date().getTime();
    fetch(`http://plato.mrl.ai:8080/contacts/add?cachebuster=${currentTimeMilliseconds}`, {
      method: "POST",
      headers: {
        api: "sommer",
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({
        name: name,
        number: number
      })
    })
      .then(this.refreshContacts())
      .catch(console.log)
  }

  personRemove = (person) => {
    const contactIndex = this.state.contacts
    .findIndex(contact => {
      return contact.name === person.name && contact.number === person.number;
    });
    const currentTimeMilliseconds = new Date().getTime();
    fetch(`http://plato.mrl.ai:8080/contacts/remove?cachebuster=${currentTimeMilliseconds}`, {
      method: "POST",
      headers: {
        api: "sommer",
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({
        position: contactIndex
      })
    })
      .then(this.refreshContacts())
      .catch(console.log)
  }

  render() {
    return (
      <div>
        <div class="row">
        <Profile profile={this.state.profile} />
        <AddContact Add={this.personAdd} />
        <Contacts contacts={this.state.contacts} personRemove={this.personRemove}/> 
        </div>
      </div>
    );
  }
}

export default App;
