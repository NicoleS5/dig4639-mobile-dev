import React from "react";
import "./index.css";

class newContact extends React.Component {

    render() {
    return(
            <div id="form">
              <h2>Create a New Contact:</h2>
              <form method="POST">
                  <div>
                      <input id="addName" type="text"  placeholder="Enter Name"required="required"/> 
                      <input id="addNumber" type="text" placeholder="Enter Number" equired="required" />
                      <button class ="button" type="submit" onClick={this.props.Add}>Create Contact</button>
                  </div>
              </form>
            </div>
    );
    }
}

export default newContact;