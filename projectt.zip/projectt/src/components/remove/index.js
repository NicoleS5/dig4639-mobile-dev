import React from "react";

class RemoveContact extends React.Component {

    removeItem(e) {

    }
    render() {
        return(
          // map the key of something
        );
    }
}

export default RemoveContact;