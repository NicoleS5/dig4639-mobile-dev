
import React from "react";
import "./index.css"


function Profile(props) {
    return (
        <div class="profile-title">
             <div>
                  <h2>Profile: {props.profile.name} - Has {props.profile.count} Contacts</h2>
            </div>
        </div>
    )
};

export default Profile;