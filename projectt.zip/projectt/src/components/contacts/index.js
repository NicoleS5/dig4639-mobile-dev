import React from 'react'
import "./index.css"

const Contacts = ({ contacts, personRemove }) => {

    return (
        <div class="contacts">
            {contacts.map((contact) => (
                <div>
                  <table>
                    <tr class="border_bottom">
                      <td class="colored">Name:</td>
                      <td>{contact.name}</td>
                      <td class="colored">Number:</td>
                      <td>{contact.number}</td>
                      <button onClick={() => personRemove(contact)} class = "delete">x</button>
                    </tr>
                    
                  </table>
                    
                    
                </div>
            ))}
        </div>
    )
};

export default Contacts;